To Install:
1. Extract Pre-Alpha folder to desired directory of machine.
2. Run the The Necromancer's Guide to the Apocalypse.exe.
Note: Your anti-virus may distrust the program, this is because it is a new .exe with no records in their service.

Note: The first time you run the game, it will install a number of .json files to 
"C:\Users\Owen Ryan\AppData\LocalLow\Owen Ryan Games\The Necromancer's Guide to the Apocalypse". These files contain the data relating to
scenarios and saves.

To UnInstall:
1. Delete the extracted files.
2. Go to "C:\Users\[your username]\AppData\LocalLow\Owen Ryan Games"  and delete The Necromancer's Guide to the Apocalypse folder. 

To send me Feedback, contact me at:
owenryanul@gmail.com

Thanks for playing The Necromancer's Guide to the Apocalypse Pre-Alpha.